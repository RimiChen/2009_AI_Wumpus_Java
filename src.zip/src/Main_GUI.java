import java.awt.*;
import java.net.*;
import java.util.*;
import java.io.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class Main_GUI  implements Runnable{
	static int agent_x=0;
	static int agent_y=420;
	static int agent_w=140;
	static int agent_h=140;
	static int agent_up=0;
	static int agent_left=0;
	static int agent_down=0;
	static int agent_right=1;
	static int agent_arrow=1;
	static int step_count=0;
	static String step_trace=("step"+step_count+" : start");
	
	static Picsource pic = new Picsource();
	static Brain brain = new Brain();
	static int gogo = 0;
	
	public static void main(String[] args){
		//�ŧi
		pic.game_control.worldmap.MakeMap();
		final JFrame game = new JFrame("AI_Game");
		final JLabel game0 = new JLabel(pic.getimage(1));
		JLabel game1 = new JLabel("");
		final JLabel game_panel = new JLabel(pic.getimage(2));
		final JLabel agent_field = new JLabel("");
		final JTextArea step = new JTextArea(step_trace);
		int i,j,k,l;  //for use

		JLabel[][][] each_room = new JLabel[4][4][4];
		for(i=0; i<4; i++){
			for(j=0;j<4;j++){
				for(k=0;k<4;k++){
					each_room[i][j][k]=new JLabel("");
				}
			}
		}
		//row_clown
		
		JLabel game_1_1 = new JLabel(pic.getimage(0,0,3));
		JLabel game_1_2 = new JLabel(pic.getimage(0,1,3));
		JLabel game_1_3 = new JLabel(pic.getimage(0,2,3));
		JLabel game_1_4 = new JLabel(pic.getimage(0,3,3));
		JLabel game_2_1 = new JLabel(pic.getimage(1,0,3));
		JLabel game_2_2 = new JLabel(pic.getimage(1,1,3));
		JLabel game_2_3 = new JLabel(pic.getimage(1,2,3));
		JLabel game_2_4 = new JLabel(pic.getimage(1,3,3));
		JLabel game_3_1 = new JLabel(pic.getimage(2,0,3));
		JLabel game_3_2 = new JLabel(pic.getimage(2,1,3));
		JLabel game_3_3 = new JLabel(pic.getimage(2,2,3));
		JLabel game_3_4 = new JLabel(pic.getimage(2,3,3));
		JLabel game_4_1 = new JLabel(pic.getimage(3,0,3));
		JLabel game_4_2 = new JLabel(pic.getimage(3,1,3));
		JLabel game_4_3 = new JLabel(pic.getimage(3,2,3));
		JLabel game_4_4 = new JLabel(pic.getimage(3,3,3));
		
		JButton UP = new JButton("UP");
		JButton DOWN = new JButton("DOWN");
		JButton RIGHT = new JButton("RIGHT");
		JButton LEFT = new JButton("LEFT");
		JButton ARROW = new JButton("ARROW");
		JButton GRAB = new JButton("GRAB");
		
		final JLabel walk_agent =new JLabel(pic.getimage(13));
		
		//�]�w
		game.setLayout(null);
		game.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		game.setSize(815,738);
		//game0.setBackground(Color.RED);
		//game0.setOpaque(false);
		

		game0.setBounds(0, 0, 800, 700);
		game1.setBounds(0, 600, 600, 100);
		game_panel.setBounds(600, 0, 200, 700);
		game_4_1.setBounds(20, 20, 140, 140);
		game_4_2.setBounds(160, 20, 140, 140);
		game_4_3.setBounds(300, 20, 140, 140);
		game_4_4.setBounds(440, 20, 140, 140);
		game_3_1.setBounds(20, 160, 140, 140);
		game_3_2.setBounds(160, 160, 140, 140);
		game_3_3.setBounds(300, 160, 140, 140);
		game_3_4.setBounds(440, 160, 140, 140);
		game_2_1.setBounds(20, 300, 140, 140);
		game_2_2.setBounds(160, 300, 140, 140);
		game_2_3.setBounds(300, 300, 140, 140);
		game_2_4.setBounds(440, 300, 140, 140);
		game_1_1.setBounds(20, 440, 140, 140);
		game_1_2.setBounds(160, 440, 140, 140);
		game_1_3.setBounds(300, 440, 140, 140);
		game_1_4.setBounds(440, 440, 140, 140);
		step.setBounds(50, 250, 100, 300);
		step.setOpaque(false);
		step.setForeground(Color.WHITE);
		
		for(j=0;j<4;j++){
			for(i=0;i<4;i++){
				each_room[i][j][0].setBounds(0, 0, 70, 70);
					if(pic.record[i][j][1]==1){
						each_room[i][j][0].setIcon(pic.getimage(15));
					}
				each_room[i][j][1].setBounds(70, 0, 70, 70);
					if(pic.record[i][j][2]==1){
						each_room[i][j][1].setIcon(pic.getimage(16));
					}
				each_room[i][j][2].setBounds(0, 70, 70, 70);
					if(pic.record[i][j][0]==1){
						each_room[i][j][2].setIcon(pic.getimage(14));
					}
				each_room[i][j][3].setBounds(70,70, 70, 70);
					if(pic.record[i][j][3]==1){
						each_room[i][j][3].setIcon(pic.getimage(17));
					}
					if(pic.record[i][j][4]==1){
						each_room[i][j][3].setIcon(pic.getimage(18));
					}
			}
		}
		UP.setBounds(250, 15, 100, 20);
		LEFT.setBounds(150, 35, 100, 20);
		RIGHT.setBounds(350, 35, 100, 20);
		DOWN.setBounds(250, 55, 100, 20);
		ARROW.setBounds(50, 55, 100, 20);
		GRAB.setBounds(450, 55, 100, 20);
		
		//-----------------------------

		//-----------------------------
		
		agent_field.setBounds(20, 20, 560, 560);
		walk_agent.setBounds(agent_x, agent_y, agent_w,agent_h);   //x,y=0,140,280,420
		//UP.setBounds(275, y, 50, 15);
		//���O�t�m
		agent_field.add(walk_agent);

		
		game1.add(UP);
		game1.add(DOWN);
		game1.add(RIGHT);
		game1.add(LEFT);
		game1.add(ARROW);
		game1.add(GRAB);
		
		
		game0.add(agent_field);
/*		for(i=0;i<4;i++){
			game_1_1.add(each_room[0][0][i]);
			game_1_2.add(each_room[0][1][i]);
			game_1_3.add(each_room[0][2][i]);
			game_1_4.add(each_room[0][3][i]);
			game_2_1.add(each_room[1][0][i]);
			game_2_2.add(each_room[1][1][i]);
			game_2_3.add(each_room[1][2][i]);
			game_2_4.add(each_room[1][3][i]);
			game_3_1.add(each_room[2][0][i]);
			game_3_2.add(each_room[2][1][i]);
			game_3_3.add(each_room[2][2][i]);
			game_3_4.add(each_room[2][3][i]);
			game_4_1.add(each_room[3][0][i]);
			game_4_2.add(each_room[3][1][i]);
			game_4_3.add(each_room[3][2][i]);
			game_4_4.add(each_room[3][3][i]);

		}
*/
		for(i=0;i<4;i++){
			game_1_1.add(each_room[0][0][i]);
			game_1_2.add(each_room[1][0][i]);
			game_1_3.add(each_room[2][0][i]);
			game_1_4.add(each_room[3][0][i]);
			game_2_1.add(each_room[0][1][i]);
			game_2_2.add(each_room[1][1][i]);
			game_2_3.add(each_room[2][1][i]);
			game_2_4.add(each_room[3][1][i]);
			game_3_1.add(each_room[0][2][i]);
			game_3_2.add(each_room[1][2][i]);
			game_3_3.add(each_room[2][2][i]);
			game_3_4.add(each_room[3][2][i]);
			game_4_1.add(each_room[0][3][i]);
			game_4_2.add(each_room[1][3][i]);
			game_4_3.add(each_room[2][3][i]);
			game_4_4.add(each_room[3][3][i]);

		}
		game0.add(game_1_1);
		game0.add(game_1_2);
		game0.add(game_1_3);
		game0.add(game_1_4);
		game0.add(game_2_1);
		game0.add(game_2_2);
		game0.add(game_2_3);
		game0.add(game_2_4);
		game0.add(game_3_1);
		game0.add(game_3_2);
		game0.add(game_3_3);
		game0.add(game_3_4);
		game0.add(game_4_1);
		game0.add(game_4_2);
		game0.add(game_4_3);
		game0.add(game_4_4);
		game_panel.add(step);
		
		game0.add(game1);
		game.add(game_panel);
		game.add(game0);

		
		game.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		game.setVisible(true);
		
		//---------------------------------------------------------
		//button action
		UP.addActionListener(
				new ActionListener(){
					@Override
					public void actionPerformed(ActionEvent arg0) {
						agent_left=0;
						agent_right=0;
						agent_down=0;
						if(agent_up==0){
							agent_up=1;
							walk_agent.setIcon(pic.getimage(11));
							step_count++;
							step_trace=step_trace+("\nstep"+step_count+" : turn up");
							step.setText(step_trace);
						}
						else{
							if(agent_y>0){
								agent_y=agent_y-140;
								agent_field.remove(walk_agent);
								walk_agent.setBounds(agent_x, agent_y, agent_w,agent_h);
								agent_field.add(walk_agent);
								step_count++;
								step_trace=step_trace+("\nstep"+step_count+" : up");
								step.setText(step_trace);

							}
						}
						agent_field.repaint();
						game_panel.repaint();
					}
					
				}
		);
		DOWN.addActionListener(
				new ActionListener(){
					@Override
					public void actionPerformed(ActionEvent arg0) {
						agent_left=0;
						agent_right=0;
						agent_up=0;
						if(agent_down==0){
							agent_down=1;
							walk_agent.setIcon(pic.getimage(10));
							step_count++;
							step_trace=step_trace+("\nstep"+step_count+" : turn down");
							step.setText(step_trace);
						}
						else{
							if(agent_y<420){
								agent_y=agent_y+140;
								agent_field.remove(walk_agent);
								walk_agent.setBounds(agent_x, agent_y, agent_w,agent_h);
								agent_field.add(walk_agent);
								step_count++;
								step_trace=step_trace+("\nstep"+step_count+" : down");
								step.setText(step_trace);
							}
						}
						agent_field.repaint();
					}
					
				}
		);
		RIGHT.addActionListener(
				new ActionListener(){
					@Override
					public void actionPerformed(ActionEvent arg0) {
						agent_left=0;
						agent_down=0;
						agent_up=0;
						if(agent_right==0){
							agent_right=1;
							walk_agent.setIcon(pic.getimage(13));
							step_count++;
							step_trace=step_trace+("\nstep"+step_count+" : turn right");
							step.setText(step_trace);
						}
						else{
							if(agent_x<420){
								agent_x=agent_x+140;
								agent_field.remove(walk_agent);
								walk_agent.setBounds(agent_x, agent_y, agent_w,agent_h);
								agent_field.add(walk_agent);
								step_count++;
								step_trace=step_trace+("\nstep"+step_count+" : right");
								step.setText(step_trace);
							}
						}
						agent_field.repaint();
					}
					
				}
		);
		LEFT.addActionListener(
				new ActionListener(){
					@Override
					public void actionPerformed(ActionEvent arg0) {
						agent_right=0;
						agent_down=0;
						agent_up=0;
						if(agent_left==0){
							agent_left=1;
							walk_agent.setIcon(pic.getimage(12));
							step_count++;
							step_trace=step_trace+("\nstep"+step_count+" : turn left");
							step.setText(step_trace);
						}
						else{
							if(agent_x>0){
								agent_x=agent_x-140;
								agent_field.remove(walk_agent);
								walk_agent.setBounds(agent_x, agent_y, agent_w,agent_h);
								agent_field.add(walk_agent);
								step_count++;
								step_trace=step_trace+("\nstep"+step_count+" : left");
								step.setText(step_trace);
							}
						}
						agent_field.repaint();
					}
					
				}
		);
		ARROW.addActionListener(
				new ActionListener(){
					@Override
					public void actionPerformed(ActionEvent arg0) {
						gogo = 1;
					}

				}
		);
		GRAB.addActionListener(
				new ActionListener(){
					@Override
					public void actionPerformed(ActionEvent arg0) {
						
					}

				}
		);
		//---------------------------------------------------------
		//main program
		Room now_room;
		Action action;
		int res;
		boolean notwall;
		//Thread th = ;
		
//		pic.game_control.Print();
		
		now_room = pic.game_control.GetRoom();
		brain.Tell(now_room);
		res = brain.Ask();
		
		
		
		while( pic.game_control.gameover!=true && step_count<15)
		{
			step_trace=step_trace+("\nstep"+step_count+" : " + res);
			step_count++;
			step.setText(step_trace);
			
			agent_x = pic.game_control.agent_x*140;
			agent_y = 440-pic.game_control.agent_y*140;
			System.out.println("agent: " + agent_x + " " + agent_y);
			
			agent_field.remove(walk_agent);
			walk_agent.setBounds(agent_x, agent_y, agent_w,agent_h);
			agent_field.add(walk_agent);
			agent_field.repaint();
			System.out.println("paint ");
			
			game_panel.repaint();
			
			switch( res ){
			case 0:
				pic.game_control.TurnLeft();
				break;
			case 1:
				pic.game_control.TurnRight();
				break;
			case 2:	
				notwall = pic.game_control.MoveForward();				
				if( notwall == false ){ //�O��
					System.out.println("wall!" + pic.game_control.agent_x + " " + pic.game_control.agent_y);
					brain.ThisIsWall();
				}
				else{	//���O��
					now_room = pic.game_control.GetRoom();
					brain.Tell(now_room);				
				}
				break;
			case 3:
				pic.game_control.Shoot();
				break;
			case 4:	
				pic.game_control.Grab();
				break;
			default:
				System.out.println("error: res = " + res);
			}
			
			res = brain.Ask();
			
			
		}	
		
	
		
	}
	
	public void run()
	{
		try{
		      Thread.sleep(30000);
		}catch(InterruptedException   ex){}
	
	}
	
	public void delay(int howLong)
	{
		Thread th = new Thread(this);
		th.start();	
	}

}
