
public class Action {
	static int turn_left = 0;
	static int turn_right = 1;
	static int move_forward = 2;
	static int shoot = 3;
	static int grab = 4;
	static int newmap = 5;
	static int gameover = 6;
	
}
