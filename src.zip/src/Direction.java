
public class Direction {
	static int right = 0;
	static int down = 1;
	static int left = 2;
	static int up = 3;
}
